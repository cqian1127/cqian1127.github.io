function [thhat,B] = wMODE(R,Wmod,Q,M,N,d,dprime,Iter, delta)
% 
% function thhat = MODE(R,d,dprime,Iter);
%
% Implementation of the MODE algorithm. This implementation 
% follows P. Stoica and K.C. Sharman IEE Proceedings vol 137 Feb 1990.
% See also ASSP-38 p.1132-  , and ASSP-34 p 1081-
%
% R             sample covariance matrix of the observed data. Estimated
%               using N samples.
% Wmod          Weighting matrix flag. -1 means standard, 0 means modified
% Q             Noise covariance matrix, estimated using M samples.
% M             # of signal-free samples
% N             # of samples for R estmation
% d             Number of emitters
% dprime        rank of signal covariance matrix
% Iter          Number of "iterations", usually set to 2.
%
% thhat         estimated directions
%
%%
%% Magnus Jansson 940329   
%% Modified with prewhitening step and changed weighting matrix by KW
%% 060109
%% magnusj@s3.kth.se
%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ver=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (nargin<2)
    thhat=ver;
    return
end;
    
iQ=inv(Q);
wQ=sqrtm(iQ);
R=wQ*R*wQ';
m = size(R,1);
[uu,ss,vv] = svd(R);
lam = ss(1:dprime,1:dprime);
es = inv(wQ)*uu(:,1:dprime);
%sighat = mean(diag(ss(dprime+1:m,dprime+1:m)));

if (Wmod==-1)
    W=(lam-eye(size(lam)))^2/lam;
elseif (Wmod==0)
  cho=lam+(N/M)*eye(size(lam));
  W=(lam-eye(size(lam)))^2/cho;  
end;
sighat = mean(diag(ss(dprime+1:m,dprime+1:m)));
%wchol = diag(1./sqrt(diag(lam)))*diag(diag(lam)-sighat);
wchol = chol(W);
L = es*wchol;

%[m,f]=size(L);
f = dprime;

q=floor((d-1)/2);
j=sqrt(-1);
b=zeros(d+1,1);


St=zeros(m-d,f*(d+1));
for n=1:f
  St(1:m-d,(n-1)*(d+1)+1:n*(d+1)) = toeplitz(L(d+1:m,n),L(d+1:-1:1,n));
end

wsqrtinv=eye(m-d);

for i=1:Iter

H=zeros(f*(m-d),d+1);
for n=1:f
  H((n-1)*(m-d)+1:n*(m-d),1:d+1) = wsqrtinv\St(:,n*(d+1)-d:n*(d+1));
end

  H1=H(:,1:q+1);
  H2K=fliplr(H(:,d-q+1:d+1));

  if (d==2*q+1)
   F=[real(H1+H2K) imag(H2K-H1);imag(H1+H2K) real(H1-H2K)];
  else
   F=[real(H1+H2K) imag(H2K-H1) real(H(:,q+2));...
      imag(H1+H2K) real(H1-H2K) imag(H(:,q+2))];
  end;

% Constraint: real(beta(1))=1 see Stoica Sharman for comments
[row,col]=size(F);
L=F(:,2:col);
c=F(:,1);
%%[Q,R]=qr(L,0);
%%my=-R\Q'*c
my=-L\c;         % cheaper, simpler

if max(abs(my))>5 || my(1)==0     %Change constraint (my==0 is included to
                                 %handle th=0 (d=1) however this is not good
                               %for symmetrically located sources and R=Rtrue)

 %disp('wMODE:Element in b large, constraint in MODE is changed')
  L=F(:,[1:q+1 q+3:col]);       %imag(b(1)=1
  c=F(:,q+2);
%  [Q,R]=qr(L,0);
%  my=-R\Q'*c;
   my=-L\c;
  if (d==2*q+1)
    b(1)=my(1)+j;
    b(2:q+1)=my(2:q+1)+j*my(q+2:2*q+1);
    b(q+2:2*q+2)=conj(b(q+1:-1:1));
  else
    b(1)=my(1)+j;
    b(2:q+1)=my(2:q+1)+j*my(q+2:2*q+1);
    b(q+2)=my(2*q+2);
    b(q+3:2*q+3)=conj(b(q+1:-1:1));
  end;
else
  if (d==2*q+1)
    b(1)=1+j*my(q+1);
    b(2:q+1)=my(1:q)+j*my(q+2:2*q+1);
    b(q+2:2*q+2)=conj(b(q+1:-1:1));
  else
    b(1)=1+j*my(q+1);
    b(2:q+1)=my(1:q)+j*my(q+2:2*q+1);
    b(q+2)=my(2*q+2);
    b(q+3:2*q+3)=conj(b(q+1:-1:1));
  end;
end

if i<Iter
  B=toeplitz([b(d+1);zeros(m-d-1,1)],[flipud(b);zeros(m-d-1,1)])';

wsqrtinv=sqrtm(B'*Q*B)';   %%  the inversion is made above , in the "multiplication"

end

end     % iter

thhat = sort(asin(angle(roots(b))/pi))*180/pi;
% thhat = asin( -angle(roots(b))/pi ) * 180/pi;


