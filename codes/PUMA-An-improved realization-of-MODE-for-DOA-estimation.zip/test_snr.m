clc;clear;close all;

%% If you find the code useful, please cite our paper
% C. Qian, L. Huang, M. Cao, H. C. So and J. Xie, "PUMA: An improved realization of MODE for DOA estimation," IEEE Transactions on Aerospace and Electronic Systems, vol. 53, no. 5, pp. 2128-2139, 2017.
% C. Qian, L. Huang, N. D. Sidiropoulos and H. C. So, "Enhanced PUMA for direction-of-arrival estimation and its performance analysis," IEEE Transactions on Signal Processing, vol.64, no.16, pp.4127-4137, 2016. 
%%

M = 10;
N = 50;
DOA = [-5, 2, 12];
K = length(DOA);
SNR = linspace(-10,6,11);
nT = 100;

for iS = 1:length(SNR)
    
    snr = SNR(iS);

    for iT = 1:nT
        
        if rem(iT,nT/2) == 0
            fprintf( 'n = %d, Trials = %d, total = %d\n',...
                iS, iT, (iS-1)*nT+iT );
        end
        
        x = StatSigGenerate(M, N, DOA, snr*ones(1,K));
        
        doa1(:,iT) = EPUMA(x, K, K, 3);
        doa2(:,iT) = EPUMA(x, K, K+1, 3);
        doa3(:,iT) = rMUSIC(x, K, 'FBSS', 2);
        [doa4(:,iT),doa5(:,iT)] = MODEX(x, K);
        
    end
    
    RMSE1(iS) = rmse(doa1, DOA);
    RMSE2(iS) = rmse(doa2, DOA);
    RMSE3(iS) = rmse(doa3, DOA);
    RMSE4(iS) = rmse(doa4, DOA);
    RMSE5(iS) = rmse(doa5, DOA);
    
    [x, A, R_idl, Rs] = StatSigGenerate(M, N, DOA, snr*ones(1,K));
    CRB(iS) = crbdet_w(A,R_idl,Rs,DOA,N,1)*(180/pi)^2;
    
end

mz = 8;
lw = 2;

figure
semilogy(SNR, RMSE1.^0.5, '-p', 'markersize', mz, 'linewidth', 2); hold on;
semilogy(SNR, RMSE2.^0.5, '-o', 'markersize', mz, 'linewidth', 2); 
semilogy(SNR, RMSE3.^0.5, '->', 'markersize', mz, 'linewidth', 2);
semilogy(SNR, RMSE4.^0.5, '-*', 'markersize', mz, 'linewidth', 2)
semilogy(SNR, RMSE5.^0.5, '-*', 'markersize', mz, 'linewidth', 2)
semilogy(SNR, CRB.^0.5, 'k', 'linewidth', 2)
xlabel('SNR (dB)'); ylabel('RMSE (degree)');
legend('PUMA', 'EPUMA', 'root-MUSIC', 'MODEX', 'MODE', 'CRB');
