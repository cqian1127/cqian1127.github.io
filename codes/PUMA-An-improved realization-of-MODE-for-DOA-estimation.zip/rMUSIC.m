function [source_doa, R] = rMUSIC(x, noDOA, mode, m)

if nargin<3
    mode = 'SCM';
    m = 0;
end

[M,N] = size(x);

if strcmp(mode,'SCM')
    R  = 1/N*x*x';
elseif strcmp(mode, 'FB')
    R = 1/N*x*x';
    J = fliplr(eye(M));
    R = 0.5*(R + J*conj(R)*J);
elseif strcmp(mode,'FOSS')
    [~,R] = FB_SS(x,m);
elseif strcmp(mode,'FBSS')
    R = FB_SS(x,m);
end

[U,S] = svd(R);
Un = U(:,noDOA+1:end);
Gn = Un*Un';

a = zeros( 2*M-1, 1 )';

for i=-(M-1):(M-1) 
    a(i+M) = sum( diag(Gn,i) );
end

a1 = roots(a);

a2 = a1(abs(a1)<1);

[~, I] = sort( abs(abs(a2)-1) );

f = a2( I(1:noDOA) );

for i = 1:noDOA,
    source_doa(i) = asin(angle(f(i))/pi) * 180/pi;
end

source_doa = -source_doa(:);

end


function [R_fb, R_f, R_b] = FB_SS(x,m)
% m is the number of SS
[M,N] = size(x);

% Forward
[M,N] = size(x);
M_L = M - m + 1;
JJ = [eye(M_L), zeros(M_L,M-M_L)];
R_f = zeros(M_L);
for i = 1:m,
    J = circshift(JJ', i-1); J = J';
    x_tmp = J*x;
    R_f = R_f + 1/N*x_tmp*x_tmp';
end

% Backward
J = fliplr(eye(M));
xb = J * conj(x);
JJ = [eye(M_L), zeros(M_L,M-M_L)];
R_b = zeros(M_L);
for i = 1:m,
    J = circshift(JJ', i-1); J = J';
    x_tmp = J*xb;
    R_b = R_b + 1/N*x_tmp*x_tmp';
end

% FB
R_fb = (R_f + R_b)/2;

end


