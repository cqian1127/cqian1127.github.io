function [A,Masks] = Generate_Mask_A(N,k)
% DFT = dftmtx(N)/sqrt(N);


Masks = randsrc(N,k,[1i -1i 1 -1]);
% Sample magnitudes and make masks 
temp = rand(size(Masks));
Masks = Masks .* ( (temp <= 0.2)*sqrt(3) + (temp > 0.2)/sqrt(2) );

A = [];
for i = 1:k
%     A = [A; fft(diag(Masks(:,i)))/sqrt(N)];
    A = [A; fft(diag(Masks(:,i)))];
end