function [DOA_EST, DOA_Cand1] = MODEX(x,n)
warning off;

[M,N] = size(x);
R = 1/N*x*x';

% [DOA_Cand1] = MODE_Stoica(x,n,mode,nT);
% [DOA_Cand2] = MODE_Stoica(x,n+1,mode,nT);
DOA_Cand1 = wMODE(R,-1,eye(M),M,N,n,n,4, 0.5);
DOA_Cand2 = wMODE(R,-1,eye(M),M,N,n+1,n,4, 0.5);
DOA_Cand = [DOA_Cand1(:); DOA_Cand2(:)];

DOA_set = combntns(DOA_Cand,n);
for i = 1:size(DOA_set,1)
    A = exp(1j*pi*[0:M-1]'*sind(DOA_set(i,:)))/sqrt(M);
%     PA1 = A/(A'*A)*A'; PA2 = eye(M) - PA1;
    if det(A'*A)<1e-6
        t(i) = 1e10;
    else
        t(i) = trace((eye(M)-A/(A'*A)*A')*R);
    end
%     t(i) = log(det( PA1*R*PA1 + trace(PA2*R)/(M-K)*PA2 ));
end
[~,I] = min(t);
DOA_EST = DOA_set(I,:);
