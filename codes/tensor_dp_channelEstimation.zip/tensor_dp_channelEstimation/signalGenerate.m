function [Y,H,S,nPaths,dl,para,noisePower] = signalGenerate(Mt, Mr, Ntr, SNR, nPaths, dl)

% no. of paths
if nargin<5
    nPaths = randi([1,6]);
    dl.y = 0.5; 
    dl.x = 0.5;
    dl.r = 0.5; 
elseif nargin<6
    dl.y = 0.5; 
    dl.x = 0.5;
    dl.r = 0.5;     
end

%% large scale fading parameters
% carrier frequency
carrierFrequency = 2*10^9;
% wave length
waveLength = 3*10^8/carrierFrequency;
% distance between BS (metters)
dist_BS_MS = 100 + 40 * rand(nPaths,1);
% path loss: free-space path loss
% pathLoss = 1./(rand(nPaths,1).^3.8+1);
pathLoss = 1./(dist_BS_MS*4*pi/waveLength).^2;
% shadowing standard deviation 4 dB
shadowing_std = 3;
% noise due to shadowing
loss_dB = 10*log10(pathLoss) + shadowing_std * randn(nPaths,1);
% average received power including shadowing
shadowing = 10.^(0.1*loss_dB);

%% array manifold
psi = pi*rand(1,nPaths)/2;
phi = pi*(rand(1,nPaths)-0.5)/2;

vx = exp(1j*dl.x*2*pi*(0:Mt.left-1)'*(sin(psi).*cos(phi)));
vy = exp(1j*dl.y*2*pi*(0:Mt.right-1)'*(sin(psi).*sin(phi)));
At  = krb(vy,vx); 

% dl.virtical*2*pi*(sin(psi).*cos(phi))
% dl.horizontal*2*pi*(sin(psi).*sin(phi))
% dl.receiver*2*pi*sin(doa)

doa = pi*(rand(1,nPaths)-0.5)*2/3;
Ar = exp(1j*dl.r*[0:Mr-1]'*2*pi*sin(doa));


%% small scale fading parameters
% std of channel
sigma_h = sqrt(shadowing);
% Rician K factor
K_p = 1*rand(nPaths, 1);
% channel vector
alpha = sqrt(size(At,1)*Mr/nPaths)...
    * (exp(-1j*2*pi*rand(nPaths,1)) .* sqrt(K_p ./ (K_p + 1)) .* sigma_h...
    + (sigma_h .* sqrt(0.5 ./ (K_p + 1) ) .* (randn(nPaths, 1) + 1j*randn(nPaths, 1))));

% alpha = random('rayleigh',nPaths,1) + 1j*random('rayleigh',1,nPaths,1);

% mimo channel with dual-polarization
NN = Mt.left*Mt.right;
H = zeros(2*Mr,2*NN);
B = []; kappa = 10^(13.2/10);
for i1 = 1:2
    for i2 = 1:2
        beta = alpha.*exp(1j*pi*randn(nPaths,1));
        beta(1) = beta(1)*sqrt(kappa/(kappa+1));
        beta(2:end) = beta(2:end)*sqrt(1/(kappa+1));
        B = [B,beta];
        H((i1-1)*Mr+1:i1*Mr, (i2-1)*NN+1:i2*NN) = sqrt(kappa/(kappa+1))*Ar * diag(beta) * At';
    end
end

tmp = orth(randn(2*NN));
S = tmp(:, 1:Ntr);


%% received signal
HS = H*S;
% noise vector
W = (randn(size(HS)) + 1j*randn(size(HS)))/sqrt(2);
noisePower = norm(HS(:))/norm(W(:))*10^(-SNR/20);
Y = HS + noisePower*W;

[~,ind] = sort(doa);
para = [doa(ind), psi(ind), phi(ind)].';
