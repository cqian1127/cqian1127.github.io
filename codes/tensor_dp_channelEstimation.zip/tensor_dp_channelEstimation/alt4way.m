%% If you find this code useful, please cite our paper:
% C. Qian, X. Fu, N. D. Sidiropoulos and Y. Yang, "Tensor-Based Channel 
% Estimation for Dual-Polarized Massive MIMO Systems," in IEEE Transactions 
% on Signal Processing. doi: 10.1109/TSP.2018.2873506

%% Thanks.

function [Hhat,A,B,C,D,para] = alt4way(H,F,A,B,C,D,dl,nRestart)

MAXNUMITER = 100;
I = size(A,1);
J = size(B,1);
K = size(C,1);
L = size(D,1);

i3 = 0;
for i1 = 1:2
    for i2 = 1:2
        i3 = i3 + 1;
        Hbreve(:,i3) = reshape(H((i1-1)*I+1:i1*I,(i2-1)*J*K+1:i2*J*K),I*J*K,1);
    end
end
X = reshape(Hbreve, [I,J,K,4]);

if (nargin < 3)
    A = randn(I,F);
    B = randn(J,F);
    C = randn(K,F);
    D = randn(L,F);
    dl.y = 0.5;
    dl.x = 0.5;
    dl.r = 0.5;
    nRestart = 4;
elseif nargin < 7
    dl.y = 0.5;
    dl.x = 0.5;
    dl.r = 0.5;
    nRestart = 1;
end

% nRestart = 10;

% Used in the A-update step:
UA = [];
for j=1:J
    for k=1:K
        UA = [UA; squeeze(X(:,j,k,:)).'];
    end
end
% Used in the B-update step:
UB = [];
for k=1:K
    for l=1:L
        UB = [UB; squeeze(X(:,:,k,l))];
    end
end
% Used in the C-update step:
UC = [];
for l=1:L
    for i=1:I
        UC = [UC; squeeze(X(i,:,:,l))];
    end
end
% Used in the D-update step:
UD = [];
for i=1:I
    for j=1:J
        UD = [UD; squeeze(X(i,j,:,:))];
    end
end

% compute current fit:
fit = 0;
for k=1:K
    for l=1:L
        model(:,:,k,l) = A*diag(C(k,:))*diag(D(l,:))*B.';
        fit = fit + norm(squeeze(X(:,:,k,l))-squeeze(model(:,:,k,l)),'fro')^2;
    end
end

fitold = 2*fit;
allfits = [];

fitprevious = fit;
for iRe = 1:nRestart
    
    if nRestart>1
        A = randn(I,F);
        B = randn(J,F);
        C = randn(K,F);
        D = randn(L,F);
    end
    
    it = 0;
    while abs((fit-fitold)/fitold) > 1e-6 && it < MAXNUMITER %& fit >10^5*eps
        it=it+1;
        fitold=fit;
        
        A = (pinv(krb(B,krb(C,D)))*UA).';
        B = (pinv(krb(C,krb(D,A)))*UB).';
        C = (pinv(krb(D,krb(A,B)))*UC).';
        D = (pinv(krb(A,krb(B,C)))*UD).';
        
        % compute new fit:
        fit = 0;
        for k=1:K
            for l=1:L
                model(:,:,k,l) = A*diag(C(k,:))*diag(D(l,:))*B.';
                fit = fit + norm(squeeze(X(:,:,k,l))-squeeze(model(:,:,k,l)),'fro')^2;
            end
        end
        allfits = [allfits; fit];
        
    end
    
    if fit<fitprevious
        A1 = A; B1 = B; C1 = C; D1 = D;
        model1 = model;
        fitprevious = fit;
    end
    
end

for i = 1:F
%     wr(i) = angle(A1(1:end-1,i)'*A(2:end,i));
    wr(i) = PUMA(A1(:,i));
    theta(i) = asin( wr(i)/(2*pi*dl.r) );
%     wx(i) = angle(B1(1:end-1,i).'*B1(2:end,i).'');
%     wy(i) = angle(C1(1:end-1,i).'*C1(2:end,i).'');
    wx(i) = PUMA(B1(:,i).'');
    wy(i) = PUMA(C1(:,i).'');
    psi(i) = asin( sqrt((wy(i)/(2*pi*dl.y)).^2 + (wx(i)/(2*pi*dl.x)).^2) );
    phi(i) = atan( (wy(i)/(2*pi*dl.y))/(wx(i)/(2*pi*dl.x)) ); %Ind = (phi<0); phi(Ind) = phi(Ind) + pi;
end

% [~,Ind] = sort(theta);
% theta = theta(Ind); psi = psi(Ind); phi = phi(Ind);
para = [theta(:); psi(:); phi(:)];

Mr = I; Mt.left = J; Mt.right = K; NN = Mt.left*Mt.right;
fun = @(a,b) exp(1j*[0:a-1]'*b(:)');
Ar = fun(Mr,wr);
Ax = fun(Mt.left,wx);
Ay = fun(Mt.right,wy);

A = krb(Ay.'',krb(Ax.'',Ar));
B = (pinv(A)*Hbreve).';

H2 = A*B.';
i3 = 0;
for i1 = 1:2
    for i2 = 1:2
        i3 = i3 + 1;
        Hhat((i1-1)*Mr+1:i1*Mr,(i2-1)*NN+1:i2*NN) = reshape(H2(:,i3),Mr,NN);
    end
end

A = Ar; B = Ax; C = Ay; D = B;

end

