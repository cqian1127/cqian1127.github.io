function [xhat, time, t] = TWF2D(Y, Masks, x, z, Params)

tic;

[n1,n2,L] = size(Masks);
m = n1*n2*L;

mu = @(t) min(1-exp(-t/330), 0.2);

A = @(I)  fft2(conj(Masks) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));
At = @(Y) sum(Masks .* ifft2(Y), 3) * size(Y,1) * size(Y,2);
obj = @(ax) sum(abs(Y(:).^0.5-abs(ax(:))).^2);

for t = 1:1000,
    Bz = A(z);
    absBz = abs(Bz);
    normz = norm(z,'fro');
    hz_norm = 1/m* norm(absBz(:).^2 - Y(:), 1);
    diff_Bz_Y = absBz.^2 - Y;
    
    E    =  (absBz  <= Params.alpha_ub * normz) .* ...
        (absBz  >= Params.alpha_lb * normz) .* ...
        (abs(diff_Bz_Y) <= Params.alpha_h * hz_norm / normz * absBz);
    C    = 2* (diff_Bz_Y) ./ conj(Bz)  .*  E;
    grad = At(C) / numel(C);
    z    = z - mu(t) * real(grad);
    
    obj_val(t) = obj(Bz);
    if t>2 && abs(obj_val(t)-obj_val(t-1))/obj_val(t-1) < 1e-7
        break;
    end
    
end

time = toc;
xhat = exp(-1i*angle(trace(x'*z))) * z;