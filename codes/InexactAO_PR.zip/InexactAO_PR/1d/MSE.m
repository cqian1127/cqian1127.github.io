function mse_theta = MSE(A,NP)

mse_theta = trace(inv(A'*A)*NP);