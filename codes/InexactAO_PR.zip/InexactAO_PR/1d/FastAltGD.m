function [xhat,time,err] = FastAltGD(y0, A0, x, z0, p, eps, maxiter)

tic;


if p<=1
    z0 = gd(y0, A0, z0, 1.3, 100, 1e-5, x);
end
if p<1
    z0 = gd(y0, A0, z0, 0.8, 100, 1e-5, x);
end



[z0,err] = gd(y0, A0, z0, p, maxiter, eps, x);
% semilogy(err)

theta = angle(z0'*x);
xhat = z0 * exp(1j*theta);

time = toc;

end


function [eigvector, eigvalue] = PowerMethod(A)
N = size(A,2);
x = randn(N,1);
for i = 1:30
    x = A*x;
    x = x/norm(x);
end
eigvector = x;
eigvalue = real(x'*A*x);
end


function [z0, err] = gd(y, A, z0, p, maxiter, eps, x)

if p==2
    mu0 = max(eig(A'*A));
end

fl = @(tt) (1+sqrt(1+4*tt^2))/2;
err = []; y_s = z0;
for i = 1:maxiter
    
    u = exp(1j*angle(A*z0));
    r = A*z0 - y.*u;
    r2 = p/2*abs(r).^(p-2);
    
    grad = A'*(r2.*r);
    	         
    if p~=2
        mu = sum(r2);
    else
        mu = mu0;
    end
    step = 1/mu;
    y_s1 = z0 - step*grad;
    
    if i==1
        lambda0 = 0;
        lambda_s = fl(lambda0);
        lambda_s1 = fl(lambda_s);
    else
        lambda_s = lambda_s1;
        lambda_s1 = fl(lambda_s);
    end
    gamma = (1-lambda_s)/lambda_s1;
    z1 = (1-gamma)*y_s1 + gamma*y_s;

    % use the same stopping criterion as MTWF and TAF
    currenterrs=norm(x - exp(-1i*angle(trace(x'*z1))) * z1, 'fro')/norm(x,'fro'); 
    
    if ~rem(i,1)
        obj0 = sum(abs(y - abs(A*z0)).^p);
        obj1 = sum(abs(y - abs(A*z1)).^p);
        err = [err, obj0];
        if abs(obj0 - obj1)/obj1<eps || currenterrs<eps
            break;
        end
    end
        
    y_s = y_s1;
    z0 = z1;
end
% semilogy(real(mu2)); hold on; semilogy(real(mut),'r'); semilogy(real(mu3),'g');
% xlabel('number of iterations'); ylabel('1/\mu');
% legend('\lambda_{max}(A^HWA)', 'trace(W)', '\lambda_{max}(A^HA)');
end
