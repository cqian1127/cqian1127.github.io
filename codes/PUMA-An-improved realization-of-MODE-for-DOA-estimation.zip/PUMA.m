function DOA = PUMA(x, K, maxIter)
if nargin<3
    maxIter = 3;
end

[M,N] = size(x);
R = 1/N*x*x';
J = fliplr(eye(M));
R = 0.5*(R + J*conj(R)*J);

r2d = @(a) a*180/pi;


[U,S] = svd(R);
Us = U(:,1:K);
S = diag(S);
D = [];
for i = 1:K
    D = [D; toeplitz(Us(K:M-1,i), Us(K:-1:1,i))];
end
f = -vec(Us(K+1:end,:));

sigman2 = mean(S(K+1:end));
SS = S(1:K);

c = D\f;
for i = 1:maxIter
    A = toeplitz([c(K),zeros(1,M-K-1)].', [fliplr(c.'),1,zeros(1,M-K-1)]);
    W = kron(diag((SS - sigman2).^2./SS), inv(A*A'));
    t1 = D'*W; t2 = t1*f; t3 = t1*D; 
    t3 = (t3+t3')/2;
    L = chol(t3,'lower');
    c = L'\(L\t2);
end

c = [1, c.'];
rs = roots(c);
phi = angle(rs);
DOA = r2d( asin(phi/pi) );
DOA = sort(DOA);

end

function a = vec(b)
a = b(:);
end

