function crb = CRB(A, x, sigma2)
% y_i = |a_i^Hx| + n_i

F = [real(A'*diag(A*x)); imag(A'*diag(A*x))] / diag(abs(A*x).^2) * [real(A'*diag(A*x)); imag(A'*diag(A*x))]';

F = F/sigma2;

crb = trace(pinv(F));