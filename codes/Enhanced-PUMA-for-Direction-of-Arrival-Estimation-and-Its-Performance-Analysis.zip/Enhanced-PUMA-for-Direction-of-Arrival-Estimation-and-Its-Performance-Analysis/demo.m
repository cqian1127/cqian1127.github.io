clc; clear; close all;

M   = 10;           % # of sensors
N   = 40;           % # of samples
doa = [1,18];       % direction-of-arrivals
K   = length(doa);  % number of sources
SNR = 10;           % signal-to-noise ratio

% array manifold, ULA with half-interelement spacing
A  = exp(1j*[0:M-1]'*pi*sind(doa));

% uncorrelated source signals
% st = (randn(K,N) + 1j*randn(K,N))/sqrt(2);

% coherent source signals
st = (randn(K,N) + 1j*randn(K,N))/sqrt(2);
st(1,:) = st(2,:);

% additive noise
nt = (randn(M,N) + 1j*randn(M,N))/sqrt(2);

% received signal
x  = A*st*10^(SNR/20) + nt;

doa_estimates = EPUMA(x, K);

norm(doa_estimates(:) - doa(:))^2