clc; clear; close all;

%% If you find this code useful, please cite our paper:
% C. Qian, X. Fu, N. D. Sidiropoulos and Y. Yang, "Tensor-Based Channel 
% Estimation for Dual-Polarized Massive MIMO Systems," in IEEE Transactions 
% on Signal Processing. doi: 10.1109/TSP.2018.2873506

%% Thanks.

% Each antenna is composed by two dipoles, so the dimension of the channel
% matrix is 2Mr * 2Mt, where Mt=Mt.left*Mt.right.
% Mt.left:  number of transmit antennas, rectangular, x-axis
% Mt.right: number of transmit antennas, rectangular: y-axis
% Mr:       number of receive antennas
% Ntr:      length of training signal, generating orthogonal pilots
% K:        number of multipath
% dl:       array inter-element spacing, containing three components:
% dl.receiver is the inter-element spacing of the receive antennas
% dl.virtical is the virtical inter-element spacing of the transmitter
% dl.horizontal is the horizontal inter-element spacing of the transmitter

Mt.right = 2;
Mt.left = 4;
Mr = 1;
Ntr = 2*(Mt.right*Mt.left);
SNR = 20;
K = 4;

[y,H,S,K,dl,para,np] = signalGenerate(Mt, Mr, Ntr, SNR, K);

% match filtering
H_ls = y*S';

%% IMDF
[H_imdf,Ar1,Ax1,Ay1,B1] = IMDF_multi(y*S', Mr, Mt, K, dl);


if Mr==1
    H_alt = alt3way(y*S',K,Ax1.'',Ay1.'',B1);
elseif Mr>1
    H_alt = alt4way(y*S',K,Ar1,Ax1.'',Ay1.'',B1);
end

norm(H_imdf - H, 'fro')^2/norm(H(:))^2
norm(H_alt - H, 'fro')^2/norm(H(:))^2

