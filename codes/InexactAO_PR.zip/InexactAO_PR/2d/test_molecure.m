clc; close all ; clear;

%% This m-file is used to generate Fig.11.

%% Set Parameters
if exist('Params')                == 0,  Params.L           = 8;    end
if isfield(Params, 'L')           == 0,  Params.L           = 8;    end
if isfield(Params, 'alpha_lb')    == 0,  Params.alpha_lb    = 0.3;  end
if isfield(Params, 'alpha_ub')    == 0,  Params.alpha_ub    = 5;    end
if isfield(Params, 'alpha_h')     == 0,  Params.alpha_h     = 5;    end
if isfield(Params, 'alpha_y')     == 0,  Params.alpha_y     = 3;    end
if isfield(Params, 'mu')          == 0,  Params.mu          = 0.2;  end
if isfield(Params, 'npower_iter') == 0,  Params.npower_iter = 50;   end


%%  Read Image
load molecule
X       =  X/norm(X,'fro');

n1      =  size(X,1);
n2      =  size(X,2);
SNR     =  0;
L       =  Params.L;
Masks   =  zeros(n1,n2,L); 
m       =  n1* n2* L;
p       =  1.3;

for ll  = 1:L, Masks(:,:,ll) = randsrc(n1,n2,[1i -1i 1 -1]); end
A       = @(I)  fft2(conj(Masks) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));
At      = @(Y) sum(Masks .* ifft2(Y), 3) * size(Y,1) * size(Y,2);

x_bsg   = 0; % block AltGD
x_altgd = 0;
x_twf   = 0;
x_mtwf  = 0;
x_taf   = 0;

nT = 8; % number of Monte-Carlo trials
parfor iT = 1:nT
    
    iT
    
    S   =  abs(A(X));
    nt  =  reshape(gaussmix(m,1,0.3,0,100), size(S));
    NP  =  sum(S(:).^2)/sum(nt(:).^2)/10^(SNR/10);
    Y2  =  S  + sqrt(NP)*nt; Y = Y2.^2;
    
    %% Initialization
    normest =  sqrt(median(Y(:))/0.455);
    z0      =  randn(n1,n2); z0 = z0/norm(z0,'fro');
    Ey      =  abs(Y) <= (Params.alpha_y)^2 * normest^2;
    Ytr     =  Y .* Ey;
    for tt = 1: Params.npower_iter,
        z0 = At(Ytr.*A(z0)); 
        z0 = z0/norm(z0,'fro');
    end
    x_init = normest * real(z0);
    
    %%
    x_twf_iT    =  TWF2D(Y, Masks, X, x_init, Params);
    x_mtwf_iT   =  medianTWF2D(Y, Masks, X, x_init, Params);
    x_altgd_iT  =  FastAltGD_2D(Y2, Masks, X, x_init, p);
    x_bsg_iT    =  BSG2D(Y2, Masks, X, x_init, p, 1);
    x_taf_iT    =  TAF2D(Y2, Masks, X, x_init);
    
    %%
    x_twf   = x_twf   + x_twf_iT;
    x_mtwf  = x_mtwf  + x_mtwf_iT;
    x_bsg   = x_bsg   + x_bsg_iT;
    x_altgd = x_altgd + x_altgd_iT;
    x_taf   = x_taf   + x_taf_iT;
    
end

%%
figure; imagesc(abs(X)); colormap jet;
title('Original')
saveas(gcf,'Original.png')

xbsg = x_bsg/nT;
figure; imagesc(abs(xbsg)); colormap jet;
title('Block AltGD')
saveas(gcf,'Block_AltGD.png')

xAltGD = x_altgd/nT;
figure; imagesc(abs(xAltGD)); colormap jet;
title('AltGD')
saveas(gcf,'AltGD.png')

xtwf = x_twf/nT;
figure; imagesc(abs(xtwf)); colormap jet;
title('TWF')
saveas(gcf,'TWF.png')

xTAF = x_taf/nT;
figure; imagesc(abs(xTAF)); colormap jet;
title('TAF')
saveas(gcf,'TAF.png')

xmtwf = x_mtwf/nT;
figure; imagesc(abs(xmtwf)); colormap jet;
title('Median TWF')
saveas(gcf,'MTWF.png')


%% output error
err_bsg = ( norm(xbsg(:)-X(:)) )^2
err_altgd = ( norm(xAltGD(:)-X(:)) )^2
err_twf = ( norm(xtwf(:)-X(:)) )^2
err_taf = ( norm(xTAF(:)-X(:)) )^2
err_mtwf = ( norm(xmtwf(:)-X(:)) )^2



