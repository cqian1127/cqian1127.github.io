%% If you find this code useful, please cite our paper:
% C. Qian, X. Fu, N. D. Sidiropoulos and Y. Yang, "Tensor-Based Channel 
% Estimation for Dual-Polarized Massive MIMO Systems," in IEEE Transactions 
% on Signal Processing. doi: 10.1109/TSP.2018.2873506

%% Thanks.

function [Hhat,A,B,C] = alt3way(H,F,A,B,C,dl,nRestart)

NN = size(H,2)/2;

MAXNUMITER = 100;
I = size(A,1);
J = size(B,1);
K = 4;


i3 = 0;
for i1 = 1:2
    for i2 = 1:2
        i3 = i3 + 1;
        Hbreve(:,i3) = reshape(H(i1,(i2-1)*NN+1:i2*NN),NN,1);
    end
end
X = reshape(Hbreve, [I,J,K]);

if (nargin < 3)
    A = randn(I,F);
    B = randn(J,F);
    C = randn(K,F);
    dl.y = 0.5;
    dl.x = 0.5;
    dl.r = 0.5;
    nRestart = 4;
elseif nargin < 6
    dl.y = 0.5;
    dl.x = 0.5;
    dl.r = 0.5;
    nRestart = 1;
end

UA = reshape(X, I, J*K).';
UB = reshape(permute(X,[2,1,3]), J, I*K).';
UC = reshape(permute(X,[3,1,2]), K, I*J).';


% compute current fit:
fit = 0;
for k=1:K
    model(:,:,k) = A*diag(C(k,:))*B.';
    fit = fit + norm(squeeze(X(:,:,k))-squeeze(model(:,:,k)),'fro')^2;
end

fitold = 2*fit;
allfits = [];

fitprevious = 2*fit;
for iRe = 1:nRestart
    
    if nRestart>1
        A = randn(I,F);
        B = randn(J,F);
        C = randn(K,F);
    end
    
    it = 0;
    while abs((fit-fitold)/fitold) > 1e-6 && it < MAXNUMITER %& fit >10^5*eps
        it=it+1;
        fitold=fit;
        
        A = (pinv(krb(C,B))*UA).';
        B = (pinv(krb(C,A))*UB).';
        C = (pinv(krb(B,A))*UC).';
        
        % compute new fit:w
        fit = norm(Hbreve - krb(B,A)*C.', 'fro')^2;
        allfits = [allfits; fit];
        
    end
    
    if fit<fitprevious
        A1 = A; B1 = B; C1 = C;
        model1 = model;
        fitprevious = fit;
    end
    
end

for i = 1:F
    wx(i) = angle(A1(1:end-1,i).'*A1(2:end,i).'');
    wy(i) = angle(B1(1:end-1,i).'*B1(2:end,i).'');
end

Ax = exp(1j*[0:I-1]'*wx(:)');
Ay = exp(1j*[0:J-1]'*wy(:)');
At = krb(Ay.'',Ax.'');
B = (pinv(At)*Hbreve).';

H2 = At*B.';
i3 = 0;
for i1 = 1:2
    for i2 = 1:2
        i3 = i3 + 1;
        Hhat(i1,(i2-1)*NN+1:i2*NN) = reshape(H2(:,i3),1,NN);
    end
end

end

