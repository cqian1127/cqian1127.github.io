function [z, time, CostFuncVal] = AltIRLS(y, A, x, p, init, eps, maxIter)
tic;warning off;

if nargin < 7
    maxIter = 1000;
end

z = init;
Y = diag(y);

obj = @(z) sum(abs(y - abs(A*z)).^p);

%=========================
CostFuncVal = [];
% if p<1.5
%     p0 = 1.5;
%     for i = 1:100
%         u = exp(1j*angle(A*z));
%         r = abs(A*z - Y*u);
%         W = p0/2* diag( ( r.^2 + 1e-6*ones(size(y)) ).^(p0/2-1) );
%         z1 = (A'*W*A)\A'*(diag(W).*y.*u);
%         z = z1;
% %         CostFuncVal = [CostFuncVal, obj(z)];
%     end
% end
if p<=1
    p0 = 1.3;
    for i = 1:100
        u = exp(1j*angle(A*z));
        r = abs(A*z - Y*u);
        W = p0/2* diag( ( r.^2 ).^(p0/2-1) );
        z1 = (A'*W*A)\A'*(diag(W).*y.*u);
        z = z1;
%         CostFuncVal = [CostFuncVal, obj(z)];
    end
end
if p<1
    p0 = 1;
    for i = 1:100
        u = exp(1j*angle(A*z));
        r = abs(A*z - Y*u);
        W = p0/2* diag( ( r.^2 + 1e-6 ).^(p0/2-1) );
        z1 = (A'*W*A)\A'*(diag(W).*y.*u);
        z = z1;
    end
end
if p<0.6
    p0 = 0.7;
    for i = 1:100
        u = exp(1j*angle(A*z));
        r = abs(A*z - Y*u);
        W = p0/2* diag( ( r.^2 + 1e-6 ).^(p0/2-1) );
        z1 = (A'*W*A)\A'*(diag(W).*y.*u);
        z = z1;
    end
end
%=========================

%=========================

for i = 1:maxIter
    
    u = exp(1j*angle(A*z));
    r = abs(A*z - Y*u);
    W = (p/2)*diag( ( r.^2 + 1e-6 ).^(p/2-1) );
    z1 = (A'*W*A)\A'*W*(y.*u);
    
    if rem(i,1)==0
        c = obj(z);
        c1 = obj(z1); 
        error = abs(c - c1)/c;
        if error<eps
            break
        end
        CostFuncVal = [CostFuncVal, c];
    end
    
    z = z1;
    
end
%=========================

% remove globe phase ambiguity
z = z1;
theta = angle(z'*x);
z = z * exp(1j*theta);

time = toc;

end

