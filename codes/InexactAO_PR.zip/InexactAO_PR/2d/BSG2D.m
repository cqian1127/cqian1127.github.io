
function [xhat,time,niter] = BSG2D(y, Masks, x, z, p, blocksize)
if nargin<6
    blocksize = 1;
end
tic;

[n1,n2,L] = size(Masks);

[z,niter] = BSG_tmp(y, Masks, z, p, blocksize, 1000, 1e-7);


time = toc;

xhat = exp(1j*angle(trace(z'*x)))*z;
end

function [xhat,t] = BSG_tmp(y, Masks, z, p, blocksize, iter, eps)
A = @(I,MF,L)  fft2(conj(MF) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));
At = @(Y,MF) sum(MF .* ifft2(Y), 3) * size(Y,1) * size(Y,2);
obj = @(ax) sum(abs(y(:)-abs(ax(:))).^2);


for t = 1:iter,
    for s = 0:blocksize:size(Masks,3)-blocksize;
        i = s+1:s+blocksize;
        if blocksize == 1
            i = s+1;
        end
        Y = y(:,:,i);
        MF = Masks(:,:,i);
        r = A(z,MF,blocksize) - Y.*exp(1j*angle(A(z,MF,blocksize)));
        r2 = abs(r).^(p-2);
        g = p/2*At(r2.*r,MF);
        step = p/2*sum(r2(:));
        z = z - 1/step*real(g);
    end
    obj_val(t) = obj(A(z,Masks,size(Masks,3)));
    if t>2 && abs(obj_val(t)-obj_val(t-1))/obj_val(t-1) < eps
        break;
    end
end
xhat = z;
end


